import random


def start_game():
    attempts=0
    
    print("Welcome to the NUMBER GUESSING GAME!")
    numb= random.randint(1,50)
    guess = input("Please choose a number between 1 and 50.   ")
    while guess !=numb:
        attempts += 1 
        try:
            guess=int(guess)
            
        except ValueError as err:
            guess= input("Uh oh, this is a numbers game, only enter numbers between 1 and 50.  ")
             
        else: 
            if guess > numb:
                guess=int(input("Its lower! Please try again.  "))
                
            elif guess<numb:
                guess = int(input("Its higher! Please try again.  "))

    if numb == guess: 
        print("You got it! You guessed the right number in {} tries! ".format(attempts))
        print("Thanks for playing. ")

start_game()